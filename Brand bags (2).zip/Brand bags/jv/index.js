
//    1. Slider automático de imágenes
// ============================================


// ── SLIDER DE IMÁGENES ──────────────────────
// Cambia la imagen del hero cada 3 segundos

let indiceSlide = 0; // Empieza en la primera imagen

function mostrarSlides() {
  // Obtiene todas las diapositivas
  const slides = document.getElementsByClassName('slides');

  // Oculta todas las diapositivas
  for (let i = 0; i < slides.length; i++) {
    slides[i].style.display = 'none';
  }

  // Avanza al siguiente slide

  indiceSlide++;

  // Si llegó al final, vuelve al primero
  if (indiceSlide > slides.length) {
    indiceSlide = 1;
  }

  // Muestra el slide actual
  slides[indiceSlide - 1].style.display = 'block';

  // Espera 3 segundos y repite
  setTimeout(mostrarSlides, 3000);
}

// Arranca el slider
mostrarSlides();
