// ===============================
// CARRITO SIMPLE
// ===============================


// ---------- ELEMENTOS HTML ----------

let cartItems = document.getElementById("cartItems");
let emptyCart = document.getElementById("emptyCart");
let cartSummary = document.getElementById("cartSummary");
let clearCart = document.getElementById("clearCart");

let subtotalText = document.getElementById("subtotal");
let totalText = document.getElementById("total");
let cartCount = document.getElementById("cartCount");
let navBadge = document.getElementById("navBadge");


// ---------- OBTENER CARRITO ----------

function getCart() {
  return JSON.parse(localStorage.getItem("cart")) || [];
}


// ---------- GUARDAR CARRITO ----------

function saveCart(cart) {
  localStorage.setItem("cart", JSON.stringify(cart));
}


// ---------- CONVERTIR PRECIO ----------

function getPrice(price) {
  return parseFloat(price.replace(/[$,]/g, ""));
}


// ---------- FORMATEAR PRECIO ----------

function formatPrice(number) {
  return "$" + number.toLocaleString();
}


// ---------- ACTUALIZAR TOTALES ----------

function updateSummary(cart) {

  let subtotal = 0;
  let totalProducts = 0;

  // recorrer productos
  cart.forEach(function(item){

    subtotal = subtotal + (getPrice(item.price) * item.qty);

    totalProducts = totalProducts + item.qty;
  });

  // mostrar subtotal y total
  subtotalText.textContent = formatPrice(subtotal);
  totalText.textContent = formatPrice(subtotal);

  // mostrar cantidad de productos
  cartCount.textContent = totalProducts + " productos";

  // badge navbar
  if(totalProducts > 0){
    navBadge.style.display = "flex";
    navBadge.textContent = totalProducts;
  }else{
    navBadge.style.display = "none";
  }
}


// ---------- DIBUJAR CARRITO ----------

function drawCart(){

  let cart = getCart();

  // limpiar carrito visual
  cartItems.innerHTML = "";

  // si no hay productos
  if(cart.length === 0){

    emptyCart.style.display = "flex";
    cartSummary.style.display = "none";
    clearCart.style.display = "none";

    return;
  }

  // mostrar carrito
  emptyCart.style.display = "none";
  cartSummary.style.display = "flex";
  clearCart.style.display = "inline-flex";


  // recorrer productos
  cart.forEach(function(item, index){

    let row = document.createElement("div");

    row.className = "cart-row";

    row.innerHTML = `
    
      <img src="${item.img}">

      <div>
        <h3>${item.name}</h3>
        <p>${item.price}</p>
      </div>

      <div>

        <button class="minus" data-id="${index}">-</button>

        <span>${item.qty}</span>

        <button class="plus" data-id="${index}">+</button>

      </div>

      <h4>
        ${formatPrice(getPrice(item.price) * item.qty)}
      </h4>

      <button class="remove" data-id="${index}">
        X
      </button>
    
    `;

    cartItems.appendChild(row);

  });


  // actualizar resumen
  updateSummary(cart);



  // ---------- BOTON MENOS ----------

  document.querySelectorAll(".minus").forEach(function(btn){

    btn.addEventListener("click", function(){

      let cart = getCart();

      let index = btn.dataset.id;

      // restar cantidad
      cart[index].qty--;

      // si llega a 0 eliminar
      if(cart[index].qty <= 0){
        cart.splice(index, 1);
      }

      saveCart(cart);

      drawCart();

    });

  });



  // ---------- BOTON MAS ----------

  document.querySelectorAll(".plus").forEach(function(btn){

    btn.addEventListener("click", function(){

      let cart = getCart();

      let index = btn.dataset.id;

      // sumar
      cart[index].qty++;

      saveCart(cart);

      drawCart();

    });

  });



  // ---------- BOTON ELIMINAR ----------

  document.querySelectorAll(".remove").forEach(function(btn){

    btn.addEventListener("click", function(){

      let cart = getCart();

      let index = btn.dataset.id;

      // eliminar producto
      cart.splice(index, 1);

      saveCart(cart);

      drawCart();

    });

  });

}



// ---------- VACIAR CARRITO ----------

clearCart.addEventListener("click", function(){

  saveCart([]);

  drawCart();

});



// ---------- BOTON PAGAR ----------

document.querySelector(".checkout-btn")
.addEventListener("click", function(){

  alert("Gracias por tu compra 🛍️");

});



// ---------- INICIAR ----------

drawCart();