
//    1. Mostrar los productos guardados
//    2. Cambiar cantidades (+ y -)
//    3. Eliminar productos
//    4. Calcular el total
//    5. Vaciar el carrito
// ============================================


// ── 1. REFERENCIAS A ELEMENTOS HTML ─────────
// Aquí guardamos los elementos de la página
// para no tener que buscarlos cada vez.

const contenedorItems  = document.getElementById('cartItems');
const contenedorVacio  = document.getElementById('emptyCart');
const contenedorResumen = document.getElementById('cartSummary');
const botonVaciar      = document.getElementById('clearCart');
const textoConteo      = document.getElementById('cartCount');
const textoSubtotal    = document.getElementById('subtotal');
const textoTotal       = document.getElementById('total');
const badgeNavbar      = document.getElementById('navBadge');


// ── 2. FUNCIONES DE ALMACENAMIENTO ──────────

function obtenerCarrito() {
  return JSON.parse(localStorage.getItem('cart') || '[]');
}

function guardarCarrito(carrito) {
  localStorage.setItem('cart', JSON.stringify(carrito));
}


// ── 3. CONVERTIR PRECIO ─────────────────────
// Convierte "$6,800" (texto) → 6800 (número)

function convertirPrecio(texto) {
  return parseFloat(texto.replace(/[$,]/g, '')) || 0;
}

// Convierte 6800 (número) → "$6,800.00" (texto)
function formatearPrecio(numero) {
  return '$' + numero.toLocaleString('es-MX', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}


// ── 4. ACTUALIZAR RESUMEN ───────────────────
// Recalcula el subtotal, total y badge

function actualizarResumen(carrito) {
  // Suma precio × cantidad de cada producto
  const subtotal = carrito.reduce((acum, item) => {
    return acum + convertirPrecio(item.price) * item.qty;
  }, 0);

  textoSubtotal.textContent = formatearPrecio(subtotal);
  textoTotal.textContent    = formatearPrecio(subtotal);

  // Cuenta el total de unidades
  const totalUnidades = carrito.reduce((a, i) => a + i.qty, 0);
  textoConteo.textContent = totalUnidades + (totalUnidades === 1 ? ' producto' : ' productos');

  // Muestra u oculta el badge de la navbar
  if (totalUnidades > 0) {
    badgeNavbar.style.display = 'flex';
    badgeNavbar.textContent   = totalUnidades;
  } else {
    badgeNavbar.style.display = 'none';
  }
}


// ── 5. DIBUJAR EL CARRITO ───────────────────
// Lee el carrito y crea las tarjetas en pantalla

function dibujarCarrito() {
  const carrito = obtenerCarrito();
  contenedorItems.innerHTML = ''; // Limpia lo anterior

  // Si está vacío, muestra el estado vacío
  if (carrito.length === 0) {
    contenedorVacio.style.display   = 'flex';
    contenedorResumen.style.display = 'none';
    botonVaciar.style.display       = 'none';
    textoConteo.textContent         = '0 productos';
    return;
  }

  // Si tiene productos, muestra el resumen
  contenedorVacio.style.display   = 'none';
  contenedorResumen.style.display = 'flex';
  botonVaciar.style.display       = 'inline-flex';

  // Crea una fila por cada producto
  carrito.forEach((item, i) => {
    const fila = document.createElement('div');
    fila.className = 'cart-row';
    fila.innerHTML = `
      <img src="${item.img}" alt="${item.name}">
      <div class="cart-row-info">
        <h3>${item.name}</h3>
        <p class="cart-row-price">${item.price}</p>
        <div class="cart-row-colors">
          ${item.colors.map(c => `<span class="cart-color" style="background:${c}"></span>`).join('')}
        </div>
      </div>
      <div class="cart-qty">
        <button class="qty-btn minus" data-i="${i}">
          <i class="fa-solid fa-minus"></i>
        </button>
        <span class="qty-num">${item.qty}</span>
        <button class="qty-btn plus" data-i="${i}">
          <i class="fa-solid fa-plus"></i>
        </button>
      </div>
      <div class="cart-row-total">
        ${formatearPrecio(convertirPrecio(item.price) * item.qty)}
      </div>
      <button class="cart-remove" data-i="${i}" title="Eliminar">
        <i class="fa-solid fa-xmark"></i>
      </button>
    `;
    contenedorItems.appendChild(fila);
  });

  actualizarResumen(carrito);

  // ── Botón MENOS (restar cantidad) ──
  document.querySelectorAll('.qty-btn.minus').forEach(btn => {
    btn.addEventListener('click', () => {
      const carrito = obtenerCarrito();
      const i = +btn.dataset.i;
      if (carrito[i].qty > 1) {
        carrito[i].qty--; // Resta 1
      } else {
        carrito.splice(i, 1); // Si llega a 0, elimina el producto
      }
      guardarCarrito(carrito);
      dibujarCarrito(); // Redibuja
    });
  });

  // ── Botón MÁS (sumar cantidad) ──
  document.querySelectorAll('.qty-btn.plus').forEach(btn => {
    btn.addEventListener('click', () => {
      const carrito = obtenerCarrito();
      carrito[+btn.dataset.i].qty++; // Suma 1
      guardarCarrito(carrito);
      dibujarCarrito(); // Redibuja
    });
  });

  // ── Botón ELIMINAR (×) ──
  document.querySelectorAll('.cart-remove').forEach(btn => {
    btn.addEventListener('click', () => {
      const carrito = obtenerCarrito();
      carrito.splice(+btn.dataset.i, 1); // Quita ese producto
      guardarCarrito(carrito);
      dibujarCarrito(); // Redibuja
    });
  });
}


// ── 6. BOTÓN VACIAR TODO ────────────────────
botonVaciar.addEventListener('click', () => {
  guardarCarrito([]); // Guarda un carrito vacío
  dibujarCarrito();
});


// ── 7. BOTÓN PAGAR ──────────────────────────
document.querySelector('.checkout-btn').addEventListener('click', () => {
  alert('¡Gracias por tu compra! 🛍️');
});


// ── 8. INICIO ───────────────────────────────
dibujarCarrito();
