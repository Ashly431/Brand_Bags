// ==========================
// TIENDA SIMPLE
// ==========================



// ---------- WISHLIST ----------

// obtener wishlist
function getWishlist(){
  return JSON.parse(localStorage.getItem("wishlist")) || [];
}

// guardar wishlist
function saveWishlist(list){
  localStorage.setItem("wishlist", JSON.stringify(list));
}



// ---------- CARRITO ----------

// obtener carrito
function getCart(){
  return JSON.parse(localStorage.getItem("cart")) || [];
}

// guardar carrito
function saveCart(cart){
  localStorage.setItem("cart", JSON.stringify(cart));
}



// ---------- TOAST ----------

// mostrar mensaje
function showToast(message){

  let toast = document.getElementById("toast");

  // si no existe crear
  if(!toast){

    toast = document.createElement("div");

    toast.id = "toast";

    toast.style.cssText = `
      position:fixed;
      bottom:20px;
      left:50%;
      transform:translateX(-50%);
      background:black;
      color:white;
      padding:12px 20px;
      border-radius:10px;
    `;

    document.body.appendChild(toast);
  }

  // poner mensaje
  toast.textContent = message;

  // mostrar
  toast.style.opacity = "1";

  // ocultar después
  setTimeout(function(){
    toast.style.opacity = "0";
  }, 2500);

}




// ---------- CORAZONES ----------

// revisar productos guardados
function loadHearts(){

  let wishlist = getWishlist();

  document.querySelectorAll(".wishlist-btn")
  .forEach(function(button){

    let card = button.closest(".product-card");

    let name = card.querySelector("h3").textContent;

    let icon = button.querySelector("i");

    // buscar producto
    let exists = wishlist.some(function(item){
      return item.name === name;
    });

    // si existe poner rojo
    if(exists){

      icon.classList.replace("fa-regular","fa-solid");

      button.style.background = "#e63946";

      button.style.color = "white";
    }

  });

}



// ---------- BOTON WISHLIST ----------

document.querySelectorAll(".wishlist-btn")
.forEach(function(button){

  button.addEventListener("click", function(){

    let card = button.closest(".product-card");

    let name = card.querySelector("h3").textContent;

    let price = card.querySelector(".price").textContent;

    let img = card.querySelector("img").src;

    let wishlist = getWishlist();

    let index = wishlist.findIndex(function(item){
      return item.name === name;
    });

    let icon = button.querySelector("i");


    // agregar
    if(index === -1){

      wishlist.push({
        name:name,
        price:price,
        img:img
      });

      saveWishlist(wishlist);

      icon.classList.replace("fa-regular","fa-solid");

      button.style.background = "#e63946";

      button.style.color = "white";

      showToast("❤️ agregado a favoritos");


    }else{

      // eliminar
      wishlist.splice(index,1);

      saveWishlist(wishlist);

      icon.classList.replace("fa-solid","fa-regular");

      button.style.background = "";

      button.style.color = "";

      showToast("Eliminado de favoritos");

    }

  });

});




// ---------- BOTON CARRITO ----------

document.querySelectorAll(".cart-add-btn")
.forEach(function(button){

  button.addEventListener("click", function(){

    let card = button.closest(".product-card");

    let name = card.querySelector("h3").textContent;

    let price = card.querySelector(".price").textContent;

    let img = card.querySelector("img").src;


    let cart = getCart();

    let index = cart.findIndex(function(item){
      return item.name === name;
    });


    // si existe sumar
    if(index !== -1){

      cart[index].qty++;

    }else{

      // si no existe agregar
      cart.push({
        name:name,
        price:price,
        img:img,
        qty:1
      });

    }


    saveCart(cart);

    showToast("🛍️ agregado al carrito");


    // cambiar botón
    let original = button.innerHTML;

    button.innerHTML = "✔";

    button.style.background = "green";


    setTimeout(function(){

      button.innerHTML = original;

      button.style.background = "";

    },1200);

  });

});




// ---------- INICIAR ----------

loadHearts();