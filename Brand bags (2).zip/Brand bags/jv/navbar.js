// Revisar si hay un usuario guardado
let session = JSON.parse(localStorage.getItem("bb_session"));

// Buscar el lugar donde irá el usuario
let area = document.getElementById("userArea");

// Si existe el espacio
if (area) {

  // Si el usuario inició sesión
  if (session) {

    // Mostrar nombre y botón salir
    area.innerHTML = `
      <span>${session.name}</span>
      <button id="logoutBtn">Salir</button>
    `;

    // Cuando le den click a salir
    document.getElementById("logoutBtn").addEventListener("click", function () {

      // Borrar sesión
      localStorage.removeItem("bb_session");

      // Volver al inicio
      window.location.href = "index.html";
    });

  } else {

    // Si no hay sesión mostrar icono de usuario que lleva al login
    area.innerHTML = `
      <button class="icon-btn" onclick="window.location.href='login.html'" title="Iniciar sesión">
        <i class="fa-regular fa-user"></i>
      </button>
    `;
  }
}


// ---------- CARRITO ----------

// Buscar badge del carrito
let badge = document.getElementById("navBadge");

if (badge) {

  // Obtener carrito
  let cart = JSON.parse(localStorage.getItem("cart")) || [];

  // Variable total
  let total = 0;

  // Sumar cantidades
  cart.forEach(function (item) {
    total = total + item.qty;
  });

  // Mostrar total si hay productos
  if (total > 0) {
    badge.style.display = "flex";
    badge.textContent = total;
  }
}