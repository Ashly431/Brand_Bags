// ==========================
// WISHLIST SIMPLE
// ==========================



// ---------- ELEMENTOS HTML ----------

let wishlistList = document.getElementById("wishlistList");

let emptyState = document.getElementById("emptyState");

let clearAll = document.getElementById("clearAll");




// ---------- OBTENER WISHLIST ----------

function getWishlist(){

  return JSON.parse(localStorage.getItem("wishlist")) || [];

}



// ---------- GUARDAR WISHLIST ----------

function saveWishlist(list){

  localStorage.setItem("wishlist", JSON.stringify(list));

}





// ---------- DIBUJAR PRODUCTOS ----------

function drawWishlist(){

  let items = getWishlist();

  // limpiar
  wishlistList.innerHTML = "";



  // si no hay productos
  if(items.length === 0){

    emptyState.style.display = "flex";

    clearAll.style.display = "none";

    return;
  }



  // mostrar productos
  emptyState.style.display = "none";

  clearAll.style.display = "inline-flex";



  // recorrer productos
  items.forEach(function(item,index){

    let card = document.createElement("div");

    card.className = "wish-card";



    card.innerHTML = `

      <img src="${item.img}">

      <div class="wish-info">

        <h3>${item.name}</h3>

        <p>${item.price}</p>

        <button class="addCart" data-id="${index}">
          Agregar al carrito
        </button>

      </div>

      <button class="removeBtn" data-id="${index}">
        X
      </button>

    `;



    wishlistList.appendChild(card);

  });





  // ---------- ELIMINAR ----------

  document.querySelectorAll(".removeBtn")
  .forEach(function(button){

    button.addEventListener("click", function(){

      let list = getWishlist();

      let index = button.dataset.id;

      // eliminar producto
      list.splice(index,1);

      saveWishlist(list);

      drawWishlist();

    });

  });





  // ---------- AGREGAR AL CARRITO ----------

  document.querySelectorAll(".addCart")
  .forEach(function(button){

    button.addEventListener("click", function(){

      // cambiar texto
      button.textContent = "Agregado ✔";

      button.style.background = "green";


      setTimeout(function(){

        button.textContent = "Agregar al carrito";

        button.style.background = "";

      },1800);

    });

  });

}




// ---------- VACIAR TODO ----------

clearAll.addEventListener("click", function(){

  saveWishlist([]);

  drawWishlist();

});




// ---------- INICIAR ----------

drawWishlist();